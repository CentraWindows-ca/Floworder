import _ from "lodash";
import cn from "classnames";
import constants, {
  WorkOrderSelectOptions,
  ORDER_STATUS,
  WORKORDER_STATUS_MAPPING,
  ALL_SUBORDER_TYPES,
} from "lib/constants";
import styles from "./styles.module.scss";

const COLUMN_PRODUCT_NUMBERS = [
  "m_NumberOfWindows",
  "m_NumberOfPatioDoors",
  "m_NumberOfSwingDoors",
  "m_NumberOfDoors",
  "m_NumberOfOthers",
];
const COLUMN_PRODUCT_NUMBERS_BREAKDOWN = [
  "w__26CA",
  "w__26HY",
  "w__27DS",
  "w__29CA",
  "w__29CM",
  "w__52PD",
  "w__61DR",
  "w__68CA",
  "w__68SL",
  "w__68VS",
  "w__88SL",
  "w__88VS",
  "d__REDR",
  "d__CDLD",
  "d__RESD",
];

const COLUMN_PROJECT = [
  "m_CustomerName",
  "m_ProjectName",
  "m_ProjectManagerName",
  "m_AddOnsCount",
];

export const COLUMN_SEQUENCE_FOR_STATUS = (status, columns) => {
  let sequence = [];
  switch (status) {
    case WORKORDER_STATUS_MAPPING.Pending.key:
      sequence = [
        "m_WorkOrderNo",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        "m_InstallStatus",
        "m_RebateIcon",
        "m_TypeofGrant",
        "m_GrantStatus",
        "m_GovGrantExpiryDate_display",
        "m_FormStatus",
        "m_Branch",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "w_ProductionStartDate_colored",
        "d_ProductionStartDate_colored",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        ...COLUMN_PROJECT,
      ];
      break;
    case WORKORDER_STATUS_MAPPING.Draft.key:
      sequence = [
        "m_WorkOrderNo",
        "m_Status_display",
        "m_WinStatus_display",
        "m_DoorStatus_display",
        "m_Branch",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        "m_TotalLBRMin",
        "w_BatchNo",
        "w_BlockNo",
        "d_BatchNo",
        "d_BlockNo",
        "m_InvStatus",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        ...COLUMN_PROJECT,
      ];
      break;
    case WORKORDER_STATUS_MAPPING.Scheduled.key:
      sequence = [
        "m_WorkOrderNo",
        "m_Status_display",
        "m_WinStatus_display",
        "m_DoorStatus_display",
        "w_ProductionStartDate",
        "d_ProductionStartDate",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        "m_Branch",
        "w_ManufacturingFacility",
        "d_ManufacturingFacility",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        "m_TotalLBRMin",
        "w_BatchNo",
        "w_BlockNo",
        "d_BatchNo",
        "d_BlockNo",
        "m_InvStatus",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        ...COLUMN_PROJECT,
      ];
      break;
    case WORKORDER_STATUS_MAPPING.InProgress.key:
    case WORKORDER_STATUS_MAPPING.OnHold.key:
      sequence = [
        "m_WorkOrderNo",
        "m_Status_display",
        "m_WinStatus_display",
        "m_DoorStatus_display",
        "w_ProductionStartDate",
        "d_ProductionStartDate",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        "m_Branch",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        "m_TotalLBRMin",
        "w_BatchNo",
        "w_BlockNo",
        "d_BatchNo",
        "d_BlockNo",
        "m_InvStatus",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        ...COLUMN_PROJECT,
      ];
      break;
    case WORKORDER_STATUS_MAPPING.ReadyToShip.key:
      sequence = [
        "m_WorkOrderNo",
        "m_Status_display",
        "m_WinStatus_display",
        "m_DoorStatus_display",
        "m_ShippingStartDate",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        "m_Branch",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        "m_TotalLBRMin",
        "w_BatchNo",
        "w_BlockNo",
        "d_BatchNo",
        "d_BlockNo",
        "m_InvStatus",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        ...COLUMN_PROJECT,
      ];
      break;
    case WORKORDER_STATUS_MAPPING.Transferred.key:
      sequence = [
        "m_WorkOrderNo",
        "m_Status_display",
        "m_WinStatus_display",
        "m_DoorStatus_display",
        "m_TransferredDate",
        "m_ShippingStartDate",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        "m_Branch",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        "w_BatchNo",
        "w_BlockNo",
        "d_BatchNo",
        "d_BlockNo",
        "m_InvStatus",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        ...COLUMN_PROJECT,
      ];
      break;
    case WORKORDER_STATUS_MAPPING.Shipped.key:
      sequence = [
        "m_WorkOrderNo",
        "m_Status_display",
        "m_WinStatus_display",
        "m_DoorStatus_display",
        "m_ShippedDate",
        "m_Branch",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        "w_BatchNo",
        "w_BlockNo",
        "d_BatchNo",
        "d_BlockNo",
        "m_InvStatus",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        ...COLUMN_PROJECT,
      ];
      break;
    case WORKORDER_STATUS_MAPPING.DraftReservation.key:
    case WORKORDER_STATUS_MAPPING.ConfirmedReservation.key:
    case WORKORDER_STATUS_MAPPING.CompletedReservation.key:
      sequence = [
        "m_WorkOrderNo",
        "m_Status_display",
        "m_WinStatus_display",
        "m_DoorStatus_display",
        "w_ProductionStartDate",
        "d_ProductionStartDate",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        "m_Branch",
        "w_ManufacturingFacility",
        "d_ManufacturingFacility",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        "m_TotalLBRMin",
        "w_BatchNo",
        "w_BlockNo",
        "d_BatchNo",
        "d_BlockNo",
        "m_InvStatus",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        ...COLUMN_PROJECT,
      ];
      break;
    default: // all
      sequence = [
        "m_WorkOrderNo",
        "m_FormStatus",
        "m_Status_display",
        "m_WinStatus_display",
        "m_DoorStatus_display",
        "w_CustomerDate_display",
        "d_CustomerDate_display",
        "m_Branch",
        "w_ManufacturingFacility",
        "d_ManufacturingFacility",
        "w_GlassSupplier",
        "d_GlassSupplier",
        "m_JobType",
        "m_OrderType",
        ...COLUMN_PRODUCT_NUMBERS_BREAKDOWN,
        ...COLUMN_PRODUCT_NUMBERS,
        "w_BatchNo",
        "w_BlockNo",
        "d_BatchNo",
        "d_BlockNo",
        "m_InvStatus",
        "m_CreatedAt_display",
        "m_CreatedBy",
        "m_LastModifiedAt_display",
        "m_LastModifiedBy",
        ...COLUMN_PROJECT,
      ];
      break;
  }

  /* 
    reorder columns. the element from sequence will match columns[i].fieldCode
  */

  // Build a map of columns for quick lookup by fieldCode
  const columnMap = _.keyBy(columns, "fieldCode");

  // Ordered part: only those keys that exist in columnMap
  const orderedColumns = sequence
    .map((fieldCode) => columnMap[fieldCode])
    .filter(Boolean);

  // Remaining columns that weren't included in sequence
  // const remainingColumns = columns.filter(col => !sequence.includes(col.fieldCode));

  const columnsExpandSuborders = [];
  // expand columns
  orderedColumns.forEach((col) => {
    const { fieldCode } = col;
    const [kind, ...dbColumn] = fieldCode?.split("_");
    const fieldDisplay = dbColumn?.join("_");

    if (kind === "m") {
      columnsExpandSuborders.push(col);
    } else {
      ALL_SUBORDER_TYPES?.filter((a) =>
        a?.suborder_code?.startsWith(kind),
      )?.forEach((a) => {
        const { suborder_code, facility } = a;

        const _newCol = {
          ...col,
          fieldCode: suborder_code + "_" + fieldDisplay,
          title: (
            <>
              <span
                className={cn(
                  "badge badge-primary fw-normal fs-xs",
                  styles.badge,
                )}
              >
                {facility}
              </span>
              <span>{col.title}</span>
            </>
          ),
        }

        if (_newCol.initKey) {
          _newCol.initKey = _newCol.initKey.replace(/^[^_]+_/, suborder_code + "_")
        }

        // assemble from fieldCode to field
        columnsExpandSuborders.push(_newCol);
      });
    }
  });

  return columnsExpandSuborders;
};

export const TEMPORARY_DISPLAY_FILTER = {
  // NOND: true,
  // CHIP: true,
  // MANP: true,
  // COPD: true,
  // SYGW: true,
  // SYMA: true,
};
