import React, {
  useState,
  useEffect,
  useContext,
  useMemo,
  useCallback,
} from "react";
import cn from "classnames";
import _ from "lodash";
import constants, {
  ITEM_STATUS,
  ITEM_LITES,
  ITEM_DOOR_TYPES,
  FACILITY_ORDER,
  ITEM_FACILITY,
} from "lib/constants";
import {
  labelMapping,
  applyField,
} from "lib/constants/production_constants_labelMapping";

import Editable from "components/molecule/Editable";
import TableSortable from "components/atom/TableSortable";
import Tooltip from "components/atom/Tooltip";
// styles

import { LocalDataContext_items } from "../LocalDataProvider";
import {
  ToggleBlock,
  DisplayBlock,
  displayFilterForProductItems,
} from "../Com";
import Modal_ItemEdit from "./Modal_ItemEdit";
// styles
import stylesRoot from "../styles.module.scss";
import stylesCurrent from "./styles.module.scss";

const styles = { ...stylesRoot, ...stylesCurrent };

// const getCategoryBySystem = (system) => {};

const Com = ({ title, id }) => {
  const {
    setExpands,
    uiOrderType,
    dictionary,
    onBatchUpdateItems,
    windowItems,
    doorItems,
  } = useContext(LocalDataContext_items);

  const ITEM_CATEGORIES = dictionary?.uiItemLabels || [];

  const [stats, setStats] = useState({});
  const [editingItem, setEditingItem] = useState(null);

  const [grouppedItems, setGrouppedItems] = useState({});

  useEffect(() => {
    const _stats = {};
    ITEM_CATEGORIES?.map((o) => {
      _stats[o.dictKey] = 0;
    });

    const _grouppedItems = {};

    // get item type by system code (default windows_Windows)
    const _assign_system_to_item_type = (a) => {
      const { System, Quantity } = a;
      const _cat = _.keys(dictionary.systemCategoryList)?.find((k) => {
        return dictionary.systemCategoryList[k]?.includes(System);
      });
      a.dictKey = _cat || "windows_Windows";

      _stats[a.dictKey] = _stats[a.dictKey] + Quantity;

      if (!_grouppedItems[a.dictKey]) {
        _grouppedItems[a.dictKey] = [];
      }
      _grouppedItems[a.dictKey].push(a);
    };

    windowItems?.map(_assign_system_to_item_type);
    doorItems?.map(_assign_system_to_item_type);

    setGrouppedItems(_grouppedItems);

    setStats(_stats);
  }, [windowItems, doorItems, uiOrderType]);

  const handleShowItem = (item, kind) => {
    setEditingItem({ ...item, kind });
  };

  const handleSaveItem = async (Id, item, kind) => {
    await onBatchUpdateItems(
      [
        {
          keyValue: Id,
          fields: item,
        },
      ],
      kind,
    );
  };

  const handleCloseItem = () => {
    setEditingItem(null);
  };

  const handleTabClick = (e, dictKey) => {
    // Prevent the action passing to the parent component
    e.stopPropagation();
    setExpands((prev) => ({
      ...prev,
      [id]: true,
    }));

    setTimeout(() => {
      const target = document.getElementById(dictKey);

      // NOTE: its a hack. we have sticky title, so we need to scroll 24px less
      const scrollContainer = target?.closest(".modal-body");
      if (target && scrollContainer) {
        const y = target.offsetTop - 24;
        scrollContainer.scrollTo({ top: y, behavior: "smooth" });
      }
    }, 200);
  };

  const jsxTitle = (
    <div className="flex gap-2">
      {title}
      <div className={cn("text-primary font-normal", styles.itemTabs)}>
        {ITEM_CATEGORIES?.map((o, i) => {
          const { labelCode, label, dictKey } = o;
          let itemCount = grouppedItems[dictKey]?.length || 0;
          let actualQty = stats[dictKey];
          return (
            <span
              key={`${labelCode}_${i}`}
              title={label}
              className={cn(
                styles.labelCode,
                stats[dictKey] ? styles.toolButton : styles.zero,
              )}
              onClick={
                stats[dictKey] ? (e) => handleTabClick(e, dictKey) : null
              }
            >
              {labelCode}: {itemCount}
              {itemCount !== actualQty ? (
                <span className="text-gray-400"> (qty {actualQty})</span>
              ) : null}
            </span>
          );
        })}
      </div>
    </div>
  );

  return (
    <>
      <ToggleBlock title={jsxTitle} id={id}>
        {ITEM_CATEGORIES?.sort((a, b) => {
          a.sortOrder > b.sortOrder ? 1 : -1;
        })?.map((o) => {
          const { dictKey, category } = o;

          switch (category) {
            case "Windows":
              return (
                <TableWindow
                  {...{
                    ...o,
                    handleShowItem,
                    list: grouppedItems,
                    stats,
                  }}
                  key={dictKey}
                />
              );
            case "Doors":
              return (
                <TableDoor
                  {...{
                    ...o,
                    handleShowItem,
                    list: grouppedItems,
                    stats,
                  }}
                  key={dictKey}
                />
              );
            case "Others":
              return (
                <TableOther
                  {...{
                    ...o,
                    handleShowItem,
                    list: grouppedItems,
                    stats,
                    kind: dictKey.startsWith("doors") ? "d" : "w",
                  }}
                  key={dictKey}
                />
              );
            default:
              break;
          }
        })}
      </ToggleBlock>
      <Modal_ItemEdit
        onSave={handleSaveItem}
        onHide={handleCloseItem}
        initItem={editingItem}
      />
    </>
  );
};

const TableWindow = ({ stats, handleShowItem, list, dictKey, label }) => {
  const { checkEditable, onBatchUpdateItems } = useContext(
    LocalDataContext_items,
  );

  const data = list?.[dictKey];

  const blockId = "WINDOW.windowItems";
  const group = "windowitems";
  const _isGroupEditable = checkEditable({ group });

  const {
    updatingValues,
    setUpdatingValues,
    handleUpdate,
    overridedList,
    overridedListByFacility,
    sort,
    setSort,
    filters,
    setFilters,
  } = useUpdatingValues({
    data,
    getRowId: (row) => row.Id,
  });

  const handleSave = async () => {
    // treat updating items
    const updates = _.keys(updatingValues)?.map((k) => ({
      keyValue: k,
      fields: updatingValues[k],
    }));
    await onBatchUpdateItems(updates, "w");
    setUpdatingValues({});
  };

  const columnsWindow = useMemo(() => {
    return applyField([
      {
        fieldCode: "Item",
        width: 80,
      },
      {
        fieldCode: "Facility",
        width: 150,
        render: (t, record) => {
          const updatingKey = "Facility";
          return (
            <Editable.EF_SelectWithLabel
              {...{
                value: record[updatingKey],
                onChange: (v) =>
                  handleUpdate(
                    record?.Id,
                    v || null,
                    "Facility",
                    record["Facility"],
                  ),
                id: `Facility_${record?.Id}`,
                options: ITEM_FACILITY,
                className: "form-select form-select-sm",
                disabled: !_isGroupEditable,
              }}
            />
          );
        },
      },
      {
        fieldCode: "Size",
        width: 160,
      },
      {
        title: "Qty",
        fieldCode: "Quantity",
        width: 60,
      },
      {
        fieldCode: "SubQty",
        width: 85,
      },
      {
        fieldCode: "System",
        width: 85,
      },
      {
        fieldCode: "Description",
      },
      {
        fieldCode: "HighRisk",
        width: 120,
        render: (t, record) => {
          const updatingKey = "HighRisk";
          return (
            <Editable.EF_Checkbox_Yesno
              {...{
                id: `wi_${updatingKey}_${record?.Id}`,
                value: record[updatingKey],
                onChange: (v) =>
                  handleUpdate(record?.Id, v, updatingKey, record[updatingKey]),
                disabled: !_isGroupEditable,
              }}
            />
          );
        },
      },
      {
        fieldCode: "Custom",
        width: 90,
        render: (t, record) => {
          const updatingKey = "Custom";
          return (
            <Editable.EF_Checkbox_Yesno
              {...{
                id: `wi_${updatingKey}_${record?.Id}`,
                value: record[updatingKey],
                onChange: (v) =>
                  handleUpdate(record?.Id, v, updatingKey, record[updatingKey]),
                disabled: !_isGroupEditable,
              }}
            />
          );
        },
      },
      {
        fieldCode: "BTO",
        width: 70,
        render: (t, record) => {
          const updatingKey = "BTO";
          return (
            <Editable.EF_Checkbox_Yesno
              {...{
                id: `wi_${updatingKey}_${record?.Id}`,
                value: record[updatingKey],
                onChange: (v) =>
                  handleUpdate(record?.Id, v, updatingKey, record[updatingKey]),
                disabled: !_isGroupEditable,
              }}
            />
          );
        },
      },
      {
        fieldCode: "Notes",
        render: (t, record) => {
          const updatingKey = "Notes";
          return (
            <Editable.EF_Input
              {...{
                className: "form-control form-control-sm",
                id: `wi_${updatingKey}_${record?.Id}`,
                value: record[updatingKey],
                onChange: (v) => {
                  handleUpdate(record?.Id, v, updatingKey, record[updatingKey]);
                },
                disabled: !_isGroupEditable,
                size: "sm",
                placeholder: "--",
              }}
            />
          );
        },
      },
      {
        title: "Location",
        fieldCode: "RackLocationId",
        width: 120,
        render: (t, record) => {
          const updatingKey = "RackLocationId";
          return (
            <Editable.EF_Rack
              {...{
                value: record[updatingKey],
                onChange: (v, rid, o) => {
                  handleUpdate(
                    record?.Id,
                    o.RackNumber || null,
                    "RackLocation",
                    record["RackLocation"],
                  );
                  handleUpdate(
                    record?.Id,
                    o.RecordID || null,
                    updatingKey,
                    record[updatingKey],
                  );
                },
                id: `${record?.Id}_RackLocation`,
                isDisplayAvilible: false,
                size: "sm",
                disabled: !_isGroupEditable,
              }}
            />
          );
        },
      },
      {
        fieldCode: "Status",
        width: 150,
        render: (t, record) => {
          const updatingKey = "Status";
          return (
            <Editable.EF_SelectWithLabel
              {...{
                value: record[updatingKey],
                onChange: (v) =>
                  handleUpdate(
                    record?.Id,
                    v || null,
                    "Status",
                    record["Status"],
                  ),
                id: `Status_${record?.Id}`,
                options: ITEM_STATUS,
                className: "form-select form-select-sm",
                disabled: !_isGroupEditable,
              }}
            />
          );
        },
      },
      {
        title: "",
        fieldCode: "",
        render: (t, record) => {
          return (
            <button
              className="btn btn-sm btn-outline-primary"
              onClick={() => handleShowItem(record, "w")}
            >
              Detail
            </button>
          );
        },
        width: 60,
        isNotTitle: true,
      },
    ]);
  }, [_isGroupEditable]);

  return (
    !_.isEmpty(data) && (
      <DisplayBlock id={blockId}>
        <div className={styles.togglePadding} id={dictKey}>
          <div className={cn(styles.itemSubTitle, styles.subTitle)}>
            <label>
              {label} <small className="fw-normal">( {stats[dictKey]} )</small>
            </label>
            <div>
              <button
                className="btn btn-primary btn-sm me-2"
                disabled={_.isEmpty(updatingValues) || !_isGroupEditable}
                onClick={handleSave}
              >
                Save
              </button>
              <button
                className="btn btn-secondary btn-sm"
                disabled={_.isEmpty(updatingValues) || !_isGroupEditable}
                onClick={() => setUpdatingValues({})}
              >
                Cancel
              </button>
            </div>
          </div>
          <TableSortableWithFacility
            {...{
              data: overridedList,
              overridedListByFacility,
              columns: columnsWindow,
              sort,
              setSort,
              filters,
              setFilters,
              keyField: "Id",
              className: "text-left",
              isLockFirstColumn: false,
            }}
          />
        </div>
      </DisplayBlock>
    )
  );
};

const TEMPORARY_DISABLE_FOR_FIX = true;

const TableDoor = ({ stats, handleShowItem, list, label, dictKey }) => {
  const { checkEditable, onBatchUpdateItems } = useContext(
    LocalDataContext_items,
  );

  const data = list?.[dictKey];

  const blockId = "DOOR.doorItems";
  const group = "dooritems";
  const _isGroupEditable = checkEditable({ group });

  const handleOnClick = (...p) => {
    handleShowItem(...p);
    // alert(
    //   "Please make change from production tracking platform (https://production-tracking.centra.ca/)",
    // );
  };

  const {
    updatingValues,
    setUpdatingValues,
    handleUpdate,
    overridedList,
    overridedListByFacility,
    sort,
    setSort,
    filters,
    setFilters,
  } = useUpdatingValues({
    data,
    getRowId: (row) => row.Id,
  });

  const handleSave = async () => {
    // treat updating items
    const updates = _.keys(updatingValues)?.map((k) => ({
      keyValue: k,
      fields: updatingValues[k],
    }));
    await onBatchUpdateItems(updates, "d");
    setUpdatingValues({});
  };

  const columns = applyField([
    {
      fieldCode: "Item",
      width: 80,
    },
    {
      fieldCode: "Facility",
      width: 150,
      render: (t, record) => {
        const updatingKey = "Facility";
        return (
          <Editable.EF_SelectWithLabel
            {...{
              value: record[updatingKey],
              onChange: (v) =>
                handleUpdate(
                  record?.Id,
                  v || null,
                  "Facility",
                  record["Facility"],
                ),
              id: `Facility_${record?.Id}`,
              options: ITEM_FACILITY,
              className: "form-select form-select-sm",
              disabled: !_isGroupEditable,
            }}
          />
        );
      },
    },
    {
      fieldCode: "Size",
      width: 160,
    },
    {
      title: "Qty",
      fieldCode: "Quantity",
      width: 60,
    },
    {
      fieldCode: "SubQty",
      width: 70,
    },
    {
      fieldCode: "System",
      width: 70,
    },
    {
      fieldCode: "Description",
    },
    {
      fieldCode: "BTO",
      width: 70,
      render: (t, record) => {
        const updatingKey = "BTO";
        const overrideValue = updatingValues?.[record?.Id]?.[updatingKey];

        return (
          <Editable.EF_Checkbox_Yesno
            {...{
              id: `di_${updatingKey}_${record?.Id}`,
              value:
                overrideValue !== undefined
                  ? overrideValue
                  : record[updatingKey],
              onChange: (v) =>
                handleUpdate(
                  record?.Id,
                  v || null,
                  updatingKey,
                  record[updatingKey],
                ),
              disabled: !_isGroupEditable || TEMPORARY_DISABLE_FOR_FIX,
            }}
          />
        );
      },
    },
    !constants.DEV_HOLDING_FEATURES.v20250113_multipoint && {
      fieldCode: "Multipoint",
      width: 110,
      render: (t, record) => {
        const updatingKey = "Multipoint";
        const overrideValue = updatingValues?.[record?.Id]?.[updatingKey];

        return (
          <Editable.EF_Checkbox_Yesno
            {...{
              id: `di_${updatingKey}_${record?.Id}`,
              value:
                overrideValue !== undefined
                  ? overrideValue
                  : record[updatingKey],
              onChange: (v) =>
                handleUpdate(
                  record?.Id,
                  v || null,
                  updatingKey,
                  record[updatingKey],
                ),
              disabled: !_isGroupEditable || TEMPORARY_DISABLE_FOR_FIX,
            }}
          />
        );
      },
    },
    {
      fieldCode: "Notes",
      render: (t, record) => {
        const updatingKey = "Notes";
        const overrideValue = updatingValues?.[record?.Id]?.[updatingKey];

        return (
          <Editable.EF_Input
            {...{
              id: `di_${updatingKey}_${record?.Id}`,
              value:
                overrideValue !== undefined
                  ? overrideValue
                  : record[updatingKey],
              onChange: (v) =>
                handleUpdate(record?.Id, v, updatingKey, record[updatingKey]),
              disabled: !_isGroupEditable,
              size: "sm",
              placeholder: "--",
            }}
          />
        );
      },
    },
    {
      title: "Location",
      fieldCode: "RackLocationId",
      width: 120,
      render: (t, record) => {
        const updatingKey = "RackLocationId";
        const overrideValue = updatingValues?.[record?.Id]?.[updatingKey];
        return (
          <Editable.EF_Rack
            {...{
              value:
                overrideValue !== undefined
                  ? overrideValue
                  : record[updatingKey],
              onChange: (v, rid, o) => {
                handleUpdate(
                  record?.Id,
                  o.RackNumber || null,
                  "RackLocation",
                  record["RackLocation"],
                );
                handleUpdate(
                  record?.Id,
                  o.RecordID || null,
                  updatingKey,
                  record[updatingKey],
                );
              },
              id: `${record?.Id}_RackLocation`,
              isDisplayAvilible: false,
              size: "sm",
              disabled: !_isGroupEditable,
            }}
          />
        );
      },
    },
    {
      fieldCode: "Status",
      width: 150,
      render: (t, record) => {
        const updatingKey = "Status";
        const overrideValue = updatingValues?.[record?.Id]?.[updatingKey];
        return (
          <Editable.EF_SelectWithLabel
            {...{
              value:
                overrideValue !== undefined
                  ? overrideValue
                  : record[updatingKey],
              onChange: (v) =>
                handleUpdate(record?.Id, v || null, "Status", record["Status"]),
              id: `Status_${record?.Id}`,
              options: ITEM_STATUS,
              className: "form-select form-select-sm",
              disabled: !_isGroupEditable,
            }}
          />
        );
      },
    },
    {
      title: "",
      fieldCode: "",
      render: (t, record) => {
        return (
          <button
            className="btn btn-sm btn-outline-primary"
            onClick={() => handleOnClick(record, "d")}
          >
            Detail
          </button>
        );
      },
      width: 70,
      isNotTitle: true,
    },
  ]);

  return (
    !_.isEmpty(data) && (
      <DisplayBlock id={blockId}>
        <div className={styles.togglePadding} id={dictKey}>
          <div className={cn(styles.itemSubTitle, styles.subTitle)}>
            <label>
              {label} <small className="fw-normal">( {stats[dictKey]} )</small>
            </label>
            <div>
              <button
                className="btn btn-primary btn-sm me-2"
                disabled={_.isEmpty(updatingValues) || !_isGroupEditable}
                onClick={handleSave}
              >
                Save
              </button>
              <button
                className="btn btn-secondary btn-sm"
                disabled={_.isEmpty(updatingValues) || !_isGroupEditable}
                onClick={() => setUpdatingValues({})}
              >
                Cancel
              </button>
            </div>
          </div>
          <TableSortableWithFacility
            {...{
              data: overridedList,
              overridedListByFacility,
              columns,
              sort,
              setSort,
              filters,
              setFilters,
              keyField: "Id",
              className: "text-left",
              isLockFirstColumn: false,
            }}
          />
        </div>
      </DisplayBlock>
    )
  );
};

const initialValueOfStatus = ITEM_STATUS?.find((a) => a.sort === 0)?.fieldCode;
const TableOther = ({ stats, list, label, dictKey, kind = "w" }) => {
  const { checkEditable, onBatchUpdateItems } = useContext(
    LocalDataContext_items,
  );

  const data = list?.[dictKey];

  const blockId = kind === "w" ? "WINDOW.windowItems" : "DOOR.doorItems";
  const group = kind === "w" ? "windowitems" : "dooritems";
  const _isGroupEditable = checkEditable({ group });

  const [isUpdatableMapping, setIsUpdatableMapping] = useState({});
  const {
    updatingValues,
    setUpdatingValues,
    handleUpdate,
    overridedList,
    overridedListByFacility,
    sort,
    setSort,
    filters,
    setFilters,
  } = useUpdatingValues({
    data,
    getRowId: (row) => row.Id,
  });

  useEffect(() => {
    init(data);
  }, [data]);

  const init = (data) => {
    let _isUpdatableMappingInit = {};
    if (data) {
      // preset isUpdatableMapping
      data?.forEach((a) => {
        const { RackLocationId, Status, Id } = a;

        let _allowupdate = false;

        // NOTE: rack and status - if its updatable
        if (RackLocationId) _allowupdate = true;
        if (Status && Status !== initialValueOfStatus) _allowupdate = true;

        if (_allowupdate) {
          _isUpdatableMappingInit[Id] = true;
        }
      });

      setIsUpdatableMapping(_isUpdatableMappingInit);
    }

    setUpdatingValues({});
  };

  const handleSave = async () => {
    // treat updating items
    const updates = _.keys(updatingValues)?.map((k) => ({
      keyValue: k,
      fields: updatingValues[k],
    }));

    await onBatchUpdateItems(updates, kind);
    setUpdatingValues({});
    setIsUpdatableMapping({});
  };

  // ====== updatable rule
  const handleChangeIsUpdatable = (v, record) => {
    setIsUpdatableMapping((prev) => {
      return {
        ...prev,
        [record?.Id]: v,
      };
    });

    if (!v) {
      setUpdatingValues((prev) => {
        const _v = { ...prev };

        // NOTE: rack and status - if its updatable
        _.set(_v, [record?.Id, "RackLocationId"], "");
        _.set(_v, [record?.Id, "Status"], initialValueOfStatus);

        return _v;
      });
    }
  };

  const columns = applyField([
    _isGroupEditable
      ? {
          // NOTE 20250730: update/not update of others
          fieldCode: "isUpdatableMapping",
          title: "Update",
          width: 40,
          render: (t, record) => {
            const updatingKey = "isUpdatableMapping";
            return (
              <Editable.EF_Checkbox
                {...{
                  id: `di_${updatingKey}_${record?.Id}`,
                  value: isUpdatableMapping?.[record?.Id],
                  onChange: (v) => handleChangeIsUpdatable(v, record),
                }}
              />
            );
          },
        }
      : null,
    {
      fieldCode: "Item",
      width: 80,
    },
    {
      fieldCode: "Facility",
      width: 150,
      render: (t, record) => {
        const updatingKey = "Facility";
        return (
          <Editable.EF_SelectWithLabel
            {...{
              value: record[updatingKey],
              onChange: (v) =>
                handleUpdate(
                  record?.Id,
                  v || null,
                  "Facility",
                  record["Facility"],
                ),
              id: `Facility_${record?.Id}`,
              options: ITEM_FACILITY,
              className: "form-select form-select-sm",
              disabled: !_isGroupEditable,
            }}
          />
        );
      },
    },
    {
      fieldCode: "Size",
      width: 160,
    },
    {
      title: "Qty",
      fieldCode: "Quantity",
      width: 60,
    },
    {
      fieldCode: "SubQty",
      width: 70,
    },
    {
      fieldCode: "System",
      width: 70,
    },
    {
      fieldCode: "Description",
    },
    {
      fieldCode: "Notes",
      render: (t, record) => {
        const updatingKey = "Notes";
        const overrideValue = updatingValues?.[record?.Id]?.[updatingKey];

        return (
          <Editable.EF_Input
            {...{
              id: `wi_${updatingKey}_${record?.Id}`,
              value:
                overrideValue !== undefined
                  ? overrideValue
                  : record[updatingKey],
              onChange: (v) =>
                handleUpdate(record?.Id, v, updatingKey, record[updatingKey]),
              disabled: !_isGroupEditable,
              size: "sm",
              placeholder: "--",
            }}
          />
        );
      },
    },
    {
      title: "Location",
      fieldCode: "RackLocationId",
      width: 120,
      render: (t, record) => {
        const updatingKey = "RackLocationId";
        const overrideValue = updatingValues?.[record?.Id]?.[updatingKey];

        const value =
          overrideValue !== undefined ? overrideValue : record[updatingKey];

        // NOTE 20250730: update/not update of others
        if (!isUpdatableMapping?.[record?.Id]) {
          return !value || value === "Not Started" ? "" : value;
        }

        return (
          <Editable.EF_Rack
            {...{
              value,
              onChange: (v, rid, o) => {
                handleUpdate(
                  record?.Id,
                  o.RackNumber || null,
                  "RackLocation",
                  record["RackLocation"],
                );
                handleUpdate(
                  record?.Id,
                  o.RecordID || null,
                  updatingKey,
                  record[updatingKey],
                );
              },
              id: `${record?.Id}_RackLocation`,
              isDisplayAvilible: false,
              size: "sm",
              placeholder: "--",
              disabled:
                // NOTE 20250730: update/not update of others
                !isUpdatableMapping?.[record?.Id] || !_isGroupEditable,
            }}
          />
        );
      },
    },
    {
      fieldCode: "Status",
      width: 150,
      render: (t, record) => {
        const updatingKey = "Status";
        const overrideValue = updatingValues?.[record?.Id]?.[updatingKey];
        const value =
          overrideValue !== undefined ? overrideValue : record[updatingKey];

        // NOTE 20250730: update/not update of others
        if (!isUpdatableMapping?.[record?.Id]) {
          return !value || value === "Not Started" ? "" : value;
        }

        return (
          <Editable.EF_SelectWithLabel
            {...{
              value,
              onChange: (v) =>
                handleUpdate(record?.Id, v || null, "Status", record["Status"]),
              id: `Status_${record?.Id}`,
              options: ITEM_STATUS,
              className: "form-select form-select-sm",
              disabled: !_isGroupEditable,
            }}
          />
        );
      },
    },
  ]);

  return (
    !_.isEmpty(data) && (
      <DisplayBlock id={blockId}>
        <div className={styles.togglePadding} id={dictKey}>
          <div className={cn(styles.itemSubTitle, styles.subTitle)}>
            <label>
              {label} <small className="fw-normal">( {stats[dictKey]} )</small>
            </label>
            <div>
              <button
                className="btn btn-primary btn-sm me-2"
                disabled={_.isEmpty(updatingValues) || !_isGroupEditable}
                onClick={handleSave}
              >
                Save
              </button>
              <button
                className="btn btn-secondary btn-sm"
                disabled={_.isEmpty(updatingValues) || !_isGroupEditable}
                onClick={() => init(data)}
              >
                Cancel
              </button>
            </div>
          </div>
          <TableSortableWithFacility
            {...{
              data: overridedList,
              overridedListByFacility,
              columns,
              sort,
              setSort,
              filters,
              setFilters,
              keyField: "Id",
              className: "text-left",
              isLockFirstColumn: false,
            }}
          />
        </div>
      </DisplayBlock>
    )
  );
};

const TableSortableWithFacility = (props) => {
  const { permissions } = useContext(LocalDataContext_items);
  const { data, columns, overridedListByFacility } = props;

  const _isWithFacility = _.keys(overridedListByFacility)?.length > 1;

  const _headerClassName = cn(
    styles.thead,
    _isWithFacility ? styles.withFacility : "",
  );

  const _columns = useMemo(
    () =>
      displayFilterForProductItems(columns, {
        permissions,
      }),
    [columns, permissions],
  );

  if (_isWithFacility) {

    // if splitting facility: 
    return (
      <div>
        {_.sortBy(
          _.keys(overridedListByFacility),
          (k) => FACILITY_ORDER[k] || 0,
        ).map((k) => {
          const _facilityDisplay = k || "[Not Set]";

          return (
            <React.Fragment key={k}>
              <div className={cn(styles.facilityHeader, "text-slate-400")}>
                - {_facilityDisplay}
              </div>
              <TableSortable
                {...props}
                columns={_columns}
                headerClassName={_headerClassName}
                data={overridedListByFacility[k]}
              />
            </React.Fragment>
          );
        })}
      </div>
    );
  } else {

    // if not splitting facility: 
    return (
      <TableSortable
        {...props}
        columns={_columns?.filter((a) => a.fieldCode !== "Facility")}
        headerClassName={_headerClassName}
      />
    );
  }
};

export default React.memo(Com);

// === util hooks ======
const useUpdatingValues = ({ data, getRowId }) => {
  const [updatingValues, setUpdatingValues] = useState({});
  const [sort, setSort] = useState({});
  const [filters, setFilters] = useState({});
  const handleUpdate = useCallback((id, v, k, initV) => {
    setUpdatingValues((prev) => {
      const _v = { ...prev };
      if (v !== initV) {
        _.set(_v, [id, k], v);
      } else {
        _.unset(_v, [id, k]);
        if (_.isEmpty(_v[id])) {
          _.unset(_v[id]);
        }
      }

      return _v;
    });
  }, []);

  // const allFacilities = useMemo(() => {
  //   return _.uniq(data.map((a) => a.facility));
  // }, [data]);

  const sortedList = useMemo(
    () => buildSortedFilteredList(data, sort, filters),
    [data, sort, filters],
  );

  const overridedList = useMemo(
    () => applyOverrides(sortedList, updatingValues, getRowId),
    [sortedList, updatingValues],
  );

  const overridedListByFacility = useMemo(
    () =>
      _.groupBy(overridedList, (row) => {
        const v = row?.Facility;
        return v == null || v === "" ? "" : v;
      }),
    [overridedList],
  );

  return {
    updatingValues,
    setUpdatingValues,
    handleUpdate,
    sortedList,
    overridedList,
    overridedListByFacility,
    sort,
    setSort,
    filters,
    setFilters,
  };
};

const buildSortedFilteredList = (data, sort, filters) => {
  if (!data) return data;

  const sorted = _.orderBy(data, [sort?.sortBy], [sort?.dir]);

  return sorted.filter((row) => {
    return _.every(
      _.keys(filters || {})?.map((filterBy) => {
        const filterValue = filters[filterBy]?.value;
        if (!filterValue) return true;

        return row[filterBy]
          ?.toLowerCase()
          ?.includes(filterValue.toLowerCase());
      }),
    );
  });
};

const applyOverrides = (list, updatingValues, getRowId) => {
  if (!list || _.isEmpty(updatingValues)) return list;

  return list.map((row) => {
    const id = getRowId(row);
    const overridingRow = updatingValues[id];
    if (!overridingRow) return row;

    const next = { ...row };
    _.forOwn(overridingRow, (overrideValue, key) => {
      if (overrideValue !== undefined && overrideValue !== next[key]) {
        next[key] = overrideValue;
      }
    });
    return next;
  });
};
