import React, { useState, useEffect, useContext } from "react";
import cn from "classnames";
import utils from "lib/utils";
import _ from "lodash";
import constants from "lib/constants";
// styles
import styles from "./styles.module.scss";

import { LocalDataContext, LocalDataContext_data } from "./LocalDataProvider";
import { parseFieldsByfieldCode } from "lib/constants/production_constants_labelMapping";

const Com = ({ className, ...props }) => {
  const { data } = useContext(LocalDataContext_data);
  const { LbrBreakDowns, initWithOriginalStructure } =
    useContext(LocalDataContext);

  if (!data) return null;
  const sum = (fields) => {
    return _.sum(
      fields?.map((fieldCode) => {
        // spread fields
        const fieldList = parseFieldsByfieldCode(
          fieldCode,
          initWithOriginalStructure,
        );
        // sum data by fields
        return _.sum(fieldList?.map((f) => data[f]));
      }),
    );
  };

  const totalNumber = sum(
    [
      "m_NumberOfWindows",
      "m_NumberOfPatioDoors",
      "m_NumberOfDoors",
      "m_NumberOfOthers",
      "m_NumberOfSwingDoors",
    ],
  );

  const shouldShowTotal =
    [
      data["m_NumberOfWindows"],
      data["m_NumberOfDoors"],
      data["m_NumberOfSwingDoors"],
      data["m_NumberOfOthers"],
      data["m_NumberOfPatioDoors"],
    ]?.filter((a) => a)?.length > 1;

  const w_otherFields = {
    TotalGlassQty: sum(["w_TotalGlassQty"]),
    TotalBoxQty: sum(["w_TotalBoxQty"]),
    TotalScreens: sum(["w_TotalScreens"]),
    TotalLBRMin: sum(["w_TotalLBRMin"]),
    TotalPrice: sum(["w_TotalPrice"])
  };

  const d_otherFields = {
    TotalGlassQty: sum(["d_TotalGlassQty"]),
    TotalBoxQty: sum(["d_TotalBoxQty"]),
    TotalLBRMin: sum(["d_TotalLBRMin"]),
    TotalPrice: sum(["d_TotalPrice"])
  };

  const totalGlassQty = sum(["w_TotalGlassQty", "d_TotalGlassQty"]);
  const totalBoxQty = sum(["w_TotalBoxQty", "d_TotalBoxQty"]);
  const totalScreens = sum(["w_TotalScreens", "d_TotalScreens"]);

  const groupByWindowDoor = {
    w: {
      otherFields: w_otherFields,
      numbers: [
        {
          label: "Windows",
          number: data["m_NumberOfWindows"],
          displayNumber: utils.formatNumber(data["m_NumberOfWindows"]),
        },
        {
          label: "Patio Doors",
          number: data["m_NumberOfPatioDoors"],
          displayNumber: utils.formatNumber(data["m_NumberOfPatioDoors"]),
        },
        {
          label: "Swing Doors",
          number: data["m_NumberOfSwingDoors"],
          displayNumber: utils.formatNumber(data["m_NumberOfSwingDoors"]),
        },
        {
          label: "Others",
          number: data["m_NumberOfOthers"],
          displayNumber: utils.formatNumber(data["m_NumberOfOthers"]),
        },
      ],
    },
    d: {
      otherFields: d_otherFields,
      numbers: [
        {
          label: "Exterior Doors",
          number: data["m_NumberOfDoors"],
          displayNumber: utils.formatNumber(data["m_NumberOfDoors"]),
        },
      ],
    },
  };

  return (
    <>
      <div className={cn(styles.summaryContainer)}>
        <table className="table-hover table-bordered mb-0 table border">
          <thead className="bg-gray-100">
            <tr>
              <th></th>
              <th>Sales Amount</th>
              <th>Qty</th>
              <th>Glass Qty</th>
              <th>Box Qty</th>
              <th>Screen Qty</th>

              <th>LBR Min.</th>
            </tr>
          </thead>
          <tbody>
            {shouldShowTotal ? (
              <tr>
                <th>Total</th>
                <td>
                  {utils.formatCurrency2Decimal(data["m_TotalPrice"], "$")}
                </td>
                <td>{utils.formatNumber(totalNumber)}</td>
                <td>{utils.formatNumber(totalGlassQty)} </td>
                <td>{utils.formatNumber(totalBoxQty)}</td>
                <td>{utils.formatNumber(totalScreens)}</td>
                <td>{utils.formatNumber(data["m_TotalLBRMin"])}</td>
              </tr>
            ) : null}
            {_.keys(groupByWindowDoor)?.map((k) => {
              const prd = groupByWindowDoor[k];
              const numbers = groupByWindowDoor[k].numbers?.filter(
                (n) => n.number,
              );
              const colSpan = numbers.length;

              return (
                <React.Fragment key={k}>
                  {numbers?.map((num, j) => {
                    const { label, displayNumber } = num;
                    return (
                      <tr key={label}>
                        <th>{label}</th>
                        {j === 0 && (
                          <>
                            <td rowSpan={colSpan}>
                              {utils.formatCurrency2Decimal(
                                prd.otherFields?.TotalPrice,
                                "$",
                              )}
                            </td>
                          </>
                        )}

                        <td>{displayNumber}</td>
                        {j === 0 && (
                          <>
                            <td rowSpan={colSpan}>
                              {utils.formatNumber(
                                prd.otherFields?.TotalGlassQty,
                              )}
                            </td>
                            <td rowSpan={colSpan}>
                              {utils.formatNumber(prd.otherFields?.TotalBoxQty)}
                            </td>
                            <td rowSpan={colSpan}>
                              {utils.formatNumber(
                                prd.otherFields?.TotalScreens,
                              )}
                            </td>
                            <td rowSpan={colSpan}>
                              {utils.formatNumber(prd.otherFields?.TotalLBRMin)}
                            </td>
                          </>
                        )}
                      </tr>
                    );
                  })}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>

        <div>
          <div className={styles.summaryLaborsTitle}>LBR Breakdown:</div>
          <div className={styles.summaryLaborsContainer}>
            {LbrBreakDowns?.map((a) => {
              const { title, qty, lbr } = a;
              if (!qty && !lbr) {
                return null;
              }
              return (
                <div key={title} className={styles.summaryLabor}>
                  <div
                    className={cn(styles.summaryLaborSubtitle, "bg-gray-100")}
                  >
                    {title}
                  </div>
                  <div className={styles.summaryLaborNumbers}>
                    <div
                      className="justify-content-between align-items-center flex gap-3 pb-1"
                      style={{ borderBottom: "1px solid #D0D0D0" }}
                      title={`Quantity: ${utils.formatNumber(qty)}`}
                    >
                      <div className="">
                        <i className="fas fa-box me-2"></i>
                        <span>Qty</span>
                      </div>
                      <span className={cn(styles.summaryLaborNumberSpan)}>
                        {utils.formatNumber(qty)}
                      </span>
                    </div>
                    <div
                      className="justify-content-between align-items-center flex gap-3"
                      title={`Labor hours: ${utils.formatNumber(lbr)}`}
                    >
                      <div className="">
                        <i className="far fa-clock me-2"></i>
                        <span>Min</span>
                      </div>

                      <span className={cn(styles.summaryLaborNumberSpan)}>
                        {utils.formatNumber(lbr)}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </>
  );
};

export default Com;
