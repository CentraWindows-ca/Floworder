import { useState, useContext, memo } from "react";
import cn from "classnames";
import { Spin } from "antd";
import { LoadingOutlined, SaveOutlined } from "@ant-design/icons";
import { getIsRequired } from "./hooks/vconfig";
import constants, {
  WORKORDER_STATUS_MAPPING,
  GlassRowStates,
  FEATURE_CODES,
  ADDON_STATUS,
  SOURCE_OF_UI,
} from "lib/constants";
// styles
import styles from "./styles.module.scss";
import { LocalDataContext, LocalDataContext_data } from "./LocalDataProvider";
import utils from "lib/utils";
import {
  getFieldCode,
  uiWoFieldEditGroupMapping as gmp,
  parseFieldsByfieldCode,
} from "lib/constants/production_constants_labelMapping";

export const getIfFieldDisplayAsProductType = (
  {
    kind,
    uiOrderType,
    id,
    fieldCode = "m",
    displayAs,
    permissions,
    initWithOriginalStructure,
  },
  data,
) => {
  if (!fieldCode) fieldCode = id;

  let currentKind = "m";
  if (fieldCode?.startsWith("m_")) currentKind = "m";
  else if (fieldCode?.startsWith("w_")) currentKind = "w";
  else if (fieldCode?.startsWith("d_")) currentKind = "d";
  currentKind = displayAs || currentKind;

  // dont show fields if its not certain type of order
  if (!uiOrderType?.m && currentKind === "m") return null;
  if (!uiOrderType?.w && currentKind === "w") return null;
  if (!uiOrderType?.d && currentKind === "d") return null;

  let _isDisplay = true;

  // data conditions ======================
  if (fieldCode === "m_Community") {
    //
    _isDisplay &=
      data?.m_JobType === "SO" &&
      constants.checkProvince(data?.m_Branch) === "AB";
  }

  if (fieldCode === "m_ShippedDate") {
    _isDisplay &= [WORKORDER_STATUS_MAPPING.Shipped.key].includes(
      data?.m_Status,
    );
  }

  if (
    fieldCode === "m_TransferredLocation_display" ||
    fieldCode === "m_TransferredDate_display"
  ) {
    // TODO: need to discuss a new way to check transfer
    const _hasBranch = data?.m_Branch && data?.m_Branch !== "-";

    // has dbColumn ManufacturingFacility, value != main
    const _windowShow = _.some(
      parseFieldsByfieldCode(
        "w_ManufacturingFacility",
        initWithOriginalStructure,
      ),
      (_field) => {
        return data?.m_Branch !== data[_field];
      },
    );

    const _doorShow = _.some(
      parseFieldsByfieldCode(
        "d_ManufacturingFacility",
        initWithOriginalStructure,
      ),
      (_field) => {
        return data?.m_Branch !== data[_field];
      },
    );

    _isDisplay &= _hasBranch && (_windowShow || _doorShow);
  }

  // user permissions ======================
  const checkPermission = (pc, op = "canEdit") => {
    return _.get(permissions, [pc, op], false);
  };

  if (fieldCode === "m_PriceBeforeTax") {
    _isDisplay &= checkPermission(
      FEATURE_CODES["om.prod.wo.informationPriceBeforeTax"],
      "canView",
    );
  }

  // order kind ======================
  if (currentKind === kind || currentKind === "m" || kind === "m") {
    _isDisplay &= true;
  } else {
    _isDisplay &= false;
  }

  return _isDisplay;
};
export const getIfFieldDisplayForProductItems = (
  { key, id, permissions },
  data,
) => {
  let _isDisplay = true;
  const checkPermission = (pc, op = "canEdit") => {
    return _.get(permissions, [pc, op], false);
  };

  const fieldCode = key || id;

  if (fieldCode === "Facility") {
    _isDisplay &= checkPermission(
      FEATURE_CODES["om.prod.wo.itemFacility"],
      "canView",
    );
  }

  return _isDisplay;
};

export const displayFilter = (
  columnList,
  { kind, uiOrderType, permissions, initWithOriginalStructure },
) => {
  return columnList?.filter((a) => {
    const { id, fieldCode, displayAs } = a;
    // currentKind is data kind
    return getIfFieldDisplayAsProductType(
      {
        kind,
        uiOrderType,
        fieldCode: fieldCode || id,
        displayAs,
        permissions,
        initWithOriginalStructure,
      },
      a,
    );
  });
};

export const displayFilterForProductItems = (
  columnList,
  { uiOrderType, permissions },
) => {
  return columnList?.filter((a) => {
    const { key, id, displayAs } = a;
    // currentKind is data kind
    return getIfFieldDisplayForProductItems(
      {
        uiOrderType,
        key,
        id,
        displayAs,
        permissions,
      },
      a,
    );
  });
};

export const Block = memo(({ className_input, inputData, data: overridingData }) => {
  const localContext = useContext(LocalDataContext);
  const { data: contextData, validationResult } = useContext(
    LocalDataContext_data,
  );
  const { initData, onChange, checkEditable, checkAddOnField, dictionary } =
    localContext;

  const data = overridingData || contextData;

  let {
    Component,
    title,
    displayId,
    field,
    fieldCode,
    options,
    overrideOnChange,
    renderValue,
    className,
    ...rest
  } = inputData;
  if (typeof options === "function") {
    options = options(dictionary);
  }

  field = field || fieldCode;

  const className_required = getIsRequired(initData, fieldCode) && "required";

  const _value = renderValue
    ? renderValue(data?.[field], data, localContext)
    : data?.[field];
  const addon = checkAddOnField({ id: fieldCode });
  const addonClass = addon?.isSyncedFromParent ? styles.addonSync_input : "";

  let _title = title;
  if (typeof title === "function") {
    {
      _title = title(inputData);
    }
  }

  return (
    <DisplayBlock fieldCode={displayId || fieldCode}>
      <label className={cn(className_required)}>{_title}</label>
      <div className={cn(className_input)}>
        <Component
          id={field}
          value={_value}
          initValue={initData?.[field]}
          isHighlightDiff
          onChange={(v, ...o) => {
            if (typeof overrideOnChange === "function") {
              overrideOnChange(onChange, [v, ...o]);
            } else {
              onChange(v, field);
            }
          }}
          disabled={!checkEditable({ fieldCode })}
          options={options}
          errorMessage={validationResult?.[field]}
          className={cn(className, addonClass)}
          {...rest}
        />
      </div>
    </DisplayBlock>
  );
});

export const DisplayBlock = ({
  children,
  id = "m",
  fieldCode = "m",
  displayAs,
  ...props
}) => {
  // kind is UI selected kind
  const { uiOrderType, kind, permissions, initWithOriginalStructure } =
    useContext(LocalDataContext);
  const { data } = useContext(LocalDataContext_data);
  const display = getIfFieldDisplayAsProductType(
    {
      kind,
      uiOrderType,
      fieldCode: fieldCode || id,
      displayAs,
      permissions,
      initWithOriginalStructure,
    },
    data,
  );

  if (display) {
    return children;
  } else {
    return null;
  }
};

export const ToggleBlock = ({
  children,
  data,
  id,
  title,
  titleClass,
  jsxClose = null,
  ...props
}) => {
  const { onAnchor, expands, setExpands } = useContext(LocalDataContext);
  const toggle = !expands[id];

  const setToggle = () => {
    if (expands[id]) {
      setExpands((prev) => {
        const _v = JSON.parse(JSON.stringify(prev || {}));
        _v[id] = !_v[id];
        return _v;
      });
    } else {
      onAnchor(id);
    }
  };

  return (
    <div className={cn(styles.toggleContainer)} id={id}>
      <div
        className={cn(styles.toggleTitle, titleClass)}
        onClick={() => setToggle((prev) => !prev)}
      >
        {title}
        <div>
          <i
            className={cn("fa-solid", toggle ? "fa-angle-down" : "fa-angle-up")}
          ></i>
        </div>
      </div>
      {toggle ? (
        jsxClose
      ) : (
        <div className={cn(styles.toggleZone)}>{children}</div>
      )}
    </div>
  );
};

export const ToggleFull = ({
  children,
  data,
  id,
  title,
  titleClass,
  jsxClose = null,
  ...props
}) => {
  const { onAnchor, expands, setExpands } = useContext(LocalDataContext);
  const toggle = !expands[id];

  const setToggle = () => {
    if (expands[id]) {
      setExpands((prev) => {
        const _v = JSON.parse(JSON.stringify(prev || {}));
        _v[id] = !_v[id];
        return _v;
      });
    } else {
      onAnchor(id);
    }
  };

  return (
    <div className={cn(styles.toggleContainer, styles.toggleFull)} id={id}>
      <div
        className={cn(styles.toggleTitle, titleClass)}
        onClick={() => setToggle((prev) => !prev)}
      >
        {title}
        <div>
          <i
            className={cn("fa-solid", toggle ? "fa-angle-up" : "fa-angle-down")}
          ></i>
        </div>
      </div>
      {toggle ? (
        <div
          className={cn(styles.toggleFullClose)}
          onClick={() => setToggle((prev) => !prev)}
        >
          {jsxClose}
        </div>
      ) : (
        <div className={cn(styles.toggleZone)}>{children}</div>
      )}
    </div>
  );
};

export const NoData = ({ title = "No Data", className }) => {
  return (
    <div className={cn("p-2 text-center text-slate-400", className)}>
      -- {title} --
    </div>
  );
};

// ========== copied from calendar project: ==========
export const treateGlassItems = (list) => {
  const getStatus = (glassItem) => {
    let result = "Not Ordered";

    if (glassItem?.qty === glassItem?.glassQty) {
      result = "Received";
    } else if (glassItem?.orderDate) {
      result = "Ordered";
    }

    return result;
  };

  let _glassItems = [...list];
  const _newItems = [];
  _glassItems?.forEach((g, i) => {
    g.status = getStatus(g);
    g.statusObj =
      _.values(GlassRowStates).find((_grs) => _grs.label === g.status) || {};
    g.receivedExpected = `${g.qty} / ${g.glassQty}`;
    g.shipDate = utils.formatDateForMorganLegacy(g.shipDate);
    g.orderDate = utils.formatDateForMorganLegacy(g.orderDate);
  });
  const statusPriority = {
    "Not Ordered": 1,
    Ordered: 2,
    Received: 3,
  };

  _glassItems = _glassItems.sort((a, b) => {
    // Compare status priority
    const statusComparison =
      statusPriority[a.status] - statusPriority[b.status];
    if (statusComparison !== 0) {
      return statusComparison;
    }
    // If status is the same, compare item strings
    return a.item.localeCompare(b.item);
  });

  _glassItems?.forEach((g, i) => {
    const { rackInfo = [], workOrderNumber, item } = g;
    g.isFirstRow = true;
    // expand extra rows by rack info (if any)
    if (_.isEmpty(rackInfo)) {
      _newItems.push({ ...g, key: `${workOrderNumber}_${item}_${i}` });
    } else {
      g.rowSpan = rackInfo.length;

      rackInfo.map((ri, j) => {
        const { rackID, rackType, qty } = ri;
        _newItems.push({
          ...g,
          isFirstRow: j > 0 ? false : true,
          rackID,
          rackType,
          rackQty: qty,
          key: `${workOrderNumber}_${item}_${rackID}_${i}_${j}`,
        });
      });
    }
  });

  return _newItems;
};

export const checkEditableByFieldCode = ({
  fieldCode,
  permissions,
  data,
  initKind,
  sourceOfUI,
}) => {
  let isEnable = false;

  // ============ permission checking: "enable" rules ============
  const isWindowField = fieldCode?.startsWith("w_") || fieldCode?.startsWith("m_");
  const isDoorField = fieldCode?.startsWith("d_") || fieldCode?.startsWith("m_");
  const checkPermission = (pc, op = "canEdit") => {
    return _.get(permissions, [pc, op], false);
  };
  const checkGroup = (group) => {
    return gmp[group][fieldCode];
  };

  if (checkPermission(FEATURE_CODES["om.prod.wo.basic"])) {
    isEnable = isEnable || checkGroup("basic");
  }
  if (checkPermission(FEATURE_CODES["om.prod.wo.invoice"])) {
    isEnable = isEnable || checkGroup("invoice");
  }
  if (checkPermission(FEATURE_CODES["om.prod.wo.information.window"])) {
    isEnable = isEnable || (checkGroup("information") && isWindowField);
  }
  if (checkPermission(FEATURE_CODES["om.prod.wo.information.door"])) {
    isEnable = isEnable || (checkGroup("information") && isDoorField);
  }
  if (checkPermission(FEATURE_CODES["om.prod.wo.options.window"])) {
    isEnable = isEnable || (checkGroup("options") && isWindowField);
  }
  if (checkPermission(FEATURE_CODES["om.prod.wo.options.door"])) {
    isEnable = isEnable || (checkGroup("options") && isDoorField);
  }

  if (checkPermission(FEATURE_CODES["om.prod.wo.status.window"])) {
    isEnable = isEnable || (checkGroup("status") && isWindowField);
  }
  if (checkPermission(FEATURE_CODES["om.prod.wo.status.door"])) {
    isEnable = isEnable || (checkGroup("status") && isDoorField);
  }

  // ============ [VK]NOTE 250424: "Shipping guys can change shipping schedule... but not production schedule"
  if (
    checkPermission(
      FEATURE_CODES["om.prod.wo.scheduleWithoutProduction.window"],
    )
  ) {
    // schedule fileds in window type but not start date
    isEnable =
      isEnable ||
      (checkGroup("schedule") &&
        fieldCode !== "w_ProductionStartDate" &&
        isWindowField);
  }
  if (
    checkPermission(FEATURE_CODES["om.prod.wo.scheduleWithoutProduction.door"])
  ) {
    isEnable =
      isEnable ||
      (checkGroup("schedule") && fieldCode !== "d_ProductionStartDate" && isDoorField);
  }
  if (
    checkPermission(FEATURE_CODES["om.prod.wo.scheduleWithProduction.window"])
  ) {
    isEnable = isEnable || fieldCode === "w_ProductionStartDate";
  }
  if (
    checkPermission(FEATURE_CODES["om.prod.wo.scheduleWithProduction.door"])
  ) {
    isEnable = isEnable || fieldCode === "d_ProductionStartDate";
  }
  if (checkPermission(FEATURE_CODES["om.prod.wo.scheduleShippedDate"])) {
    isEnable = isEnable || fieldCode === "m_ShippedDate";
  }
  if (checkPermission(FEATURE_CODES["om.prod.wo.notes"])) {
    isEnable = isEnable || checkGroup("notes");
  }

  // ============ functional checking: "disable" rules ============
  /* 
  [VK]NOTE 20250523
  pending rule is rely on "where they open the modal". not on "what modal" they open
  here "where" means which tab (master, window, door) they search the order from
  */
  if (sourceOfUI !== SOURCE_OF_UI.iframe_forms_approval) {
    let status_ForPendingRule;
    if (initKind === "m") status_ForPendingRule = data?.["m_Status"];
    if (initKind === "w") status_ForPendingRule = data?.["m_WinStatus"];
    if (initKind === "d") status_ForPendingRule = data?.["m_DoorStatus"];

    // in forms embed, any status should ignore editable check
    if (status_ForPendingRule === WORKORDER_STATUS_MAPPING.Pending.key) {
      // check from group 'schedule', but still from field level (in case we dont pass group)
      if (!checkGroup("schedule")) {
        isEnable = false;
      }
    }
  }

  /*
  NOTE 20250729
  AddOn inheritates from parent fields doesnt allow to edit
  */
  if (data?.m_isAddOn) {
    if (checkGroup("basic")) {
      isEnable = false;
    }

    if (checkGroup("information") && fieldCode?.startsWith("m_")) {
      isEnable = false;
    }

    if (
      [
        "m_ShippingStartDate",
        "m_RevisedDeliveryDate",
        "w_CustomerDate",
        "d_CustomerDate",
      ].includes(fieldCode)
    ) {
      isEnable = false;
    }
  }



  return isEnable;
};

export const checkEditableByGroup = ({ group, permissions, data }) => {
  /*
    usually for external tables that cant be identified by id. like files, items
  */
  const isAllowWindow = _.get(
    permissions,
    [`om.prod.wo.${group}.window`, `canEdit`],
    false,
  );
  const isAllowDoor = _.get(
    permissions,
    [`om.prod.wo.${group}.door`, `canEdit`],
    false,
  );
  const isAllowBoth = _.get(
    permissions,
    [`om.prod.wo.${group}`, `canEdit`],
    false,
  );

  let isAllowAny = isAllowWindow || isAllowDoor || isAllowBoth;

  // ============ functional checking: "disable" rules ============
  // if (data?.m_Status === WORKORDER_STATUS_MAPPING.Pending.key) {
  //   // check from group 'schedule', but still from field level (in case we dont pass group)
  //   if (group !== "schedule") {
  //     return false
  //   }
  // }

  return isAllowAny;
};

export const checkAddOnFieldById = ({
  id,
  data,
  workOrderFields,
  initKind,
}) => {
  let result = { isAddOnEditable: true, isSyncedFromParent: false };

  // if data?.m_AddOnLinked === 'SPLIT', isAddOnEditable is true
  const isOrderUnlink = data?.m_AddOnLinked === ADDON_STATUS.detached;

  const fieldCode = getFieldCode(id)

  if (workOrderFields?.[fieldCode]) {
    let {
      isReadOnly, // default
      isSplitNotSync, // functional purpose
      isSyncedFromParent, // visual color purpose
      addonChildCopyParentDataWhenCreated, // additional param for visual color
    } = workOrderFields[fieldCode];

    let _editable = !isReadOnly;
    let _syncFromParent = isSyncedFromParent;

    // if we only copy parent data when created, then we should't show green color
    if (_syncFromParent && addonChildCopyParentDataWhenCreated) {
      _syncFromParent = false;
    }

    // detach has higher priority. if that happens
    if (isSplitNotSync) {
      _editable = isOrderUnlink;
      _syncFromParent = !isOrderUnlink;
    }

    result = {
      isAddOnEditable: _editable,
      isSyncedFromParent: _syncFromParent, // visual for if sync
    };
  }

  return result;
};

export default {};
