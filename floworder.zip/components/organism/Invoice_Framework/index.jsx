import React, { useState } from "react";
import { useRouter } from "next/router";
import cn from "classnames";
import _ from "lodash";
import { RedoOutlined } from "@ant-design/icons";
import { Button } from "antd";
import Tooltip from "components/atom/Tooltip";

import constants from "lib/constants";

// components
import PageContainer from "components/atom/PageContainer";
// import Search from "components/molecule/bak_Search";
import Tabs_ManufacturingFacility from "components/molecule/Tabs_ManufacturingFacility";
import { InterruptModal } from "lib/provider/InterruptProvider/InterruptModal";
import Modal_StatusUpdate from "./Modal_StatusUpdate_Invoice";
import Framework from "components/molecule/Framework";

import TabLinksFull from "components/atom/TabLinksFull";
import SideMenu_Invoice from "components/organism/Invoice_SideMenu";

// styles
import styles from "./styles.module.scss";

const Com = ({ children }) => {
  const router = useRouter();


  // ====== consts

  return (
    <Framework
      jsxSideMenu={
        <div className={styles.itemsContainer}>
          <div className={styles.itemsContainerTitle}>
            <i className="fa-solid fa-list-check me-2"></i>Invoices
          </div>
          <SideMenu_Invoice />
        </div>
      }
      className={styles.root}
    >
      <InterruptModal>
        <Modal_StatusUpdate />
      </InterruptModal>
      {children}
    </Framework>
  );
};

export default Com;
